# TweakScale Companion :: SMCE :: Change Log

* 2020-0413: 0.0.1.0 (LisiasT) for KSP >= 1.4
	+ Initial Release
